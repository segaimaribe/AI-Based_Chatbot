from dotenv import load_dotenv
import os
import requests
import json

# Load API key from .env file
load_dotenv()

# The model name is part of the URL.
# The API key is passed as a query parameter.
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file. Please set it.")

# The URL for the Gemini API using gemini-1.5-flash
# Make sure to check the latest model names from the official documentation.
GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"
headers = {"Content-Type": "application/json"}

def get_input(prompt):
    return input(f"{prompt}\n> ").strip()

def generate_career_advice(interests, skills, subjects):
    # Construct the payload for the API request
    prompt = f"""
I am a career guidance assistant. Based on the following user responses:
- Interests: {interests}
- Skills: {skills}
- Favorite Subjects: {subjects}

Suggest 2-3 suitable career options with short explanations. Keep it simple and friendly.
"""
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": prompt}
                ]
            }
        ]
    }

    try:
        # Make the API call
        response = requests.post(GEMINI_API_URL, headers=headers, data=json.dumps(payload))
        response.raise_for_status() # Raise an exception for bad status codes
        
        # Parse the JSON response
        data = response.json()
        
        # Extract the text from the response
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    
    except requests.exceptions.RequestException as e:
        return f"An error occurred with the API request: {e}"
    except (KeyError, IndexError) as e:
        return f"Error parsing API response: {e}. Response was: {response.text}"

def run_chatbot():
    print("👋 Welcome to Gemini CareerBot!")
    print("I'll ask you a few questions to recommend a suitable career.\n")

    interests = get_input("1. What are your interests?")
    skills = get_input("2. What are your top skills?")
    subjects = get_input("3. What are your favorite school subjects?")

    print("\n🤖 Thinking...\n")
    career_suggestion = generate_career_advice(interests, skills, subjects)

    print("🔍 Career Suggestions:")
    print(career_suggestion)

if __name__ == "__main__":
    run_chatbot()